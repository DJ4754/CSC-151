// Ortega first assignment song lyrics ;
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("The song lyrics are the first seven lines from Nights by Frank Ocean");
		System.out.println("'Round your city, 'round the clock");
		System.out.println("Everybody needs you");
		System.out.println("No, you can't make everybody equal");
		System.out.println("Although you got beaucoup family");
		System.out.println("You don't even got nobody bein' honest with you");
		System.out.println("Breathe 'til I evaporated");
		System.out.println("My whole body see through");
		
	}

}
