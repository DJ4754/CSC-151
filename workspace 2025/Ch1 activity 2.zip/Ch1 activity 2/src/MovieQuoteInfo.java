
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Life, uh finds a way");
		System.out.println("It was in the film Jurassic Park");
		System.out.println("The character who said the quote was Ian Malcom played by Jeff Goldblum");
		System.out.println("1993");

	}

}
